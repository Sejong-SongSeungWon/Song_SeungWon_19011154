
%% 우주궤도역학_TermProject2_19011154_송승원
% Satellite Communications Toolbox 설치 필요
% mapping toolbox 설치 필요

clear all
clc

%% given data at t_oc
mu=3.986004418*10^5;

nav_GPS_a=2.656171520181123e+04;
nav_GPS_e=0.0042;
nav_GPS_i=0.9482;
nav_GPS_omega=-2.8818;
nav_GPS_M0=-1.4279;
nav_GPS_toc=[2023 4 29 0 0 0];
nav_GPS_OMEGA=1.1493;

nav_QZSS_a=4.216443215674123e+04;
nav_QZSS_e=0.0752;
nav_QZSS_i=0.6126;
nav_QZSS_omega=-1.5565;
nav_QZSS_M0=0.4411;
nav_QZSS_toc=[2023 5 9 2 0 0];
nav_QZSS_OMEGA=1.6873;

nav_BDS_a=4.216075093297479e+04;
nav_BDS_e=0.0030;
nav_BDS_i=0.9920;
nav_BDS_omega=3.0539;
nav_BDS_M0=2.8915;
nav_BDS_toc=[2023 2 26 0 0 0];
nav_BDS_OMEGA=5.1263;

%% In Perifocal frame at t_oc

% Get E0 from M0
nav_GPS_E0= kepler_eq(nav_GPS_e,nav_GPS_M0);
nav_QZSS_E0= kepler_eq(nav_QZSS_e,nav_QZSS_M0);
nav_BDS_E0= kepler_eq(nav_BDS_e,nav_BDS_M0);

% Get True anomaly0 from E0
nav_GPS_trueanomaly0= atan2((sqrt(1-nav_GPS_e^2)*sin(nav_GPS_E0))/(1-nav_GPS_e*cos(nav_GPS_E0)),(cos(nav_GPS_E0)-nav_GPS_e)/(1-nav_GPS_e*cos(nav_GPS_E0)));
nav_QZSS_trueanomaly0= atan2((sqrt(1-nav_QZSS_e^2)*sin(nav_QZSS_E0))/(1-nav_QZSS_e*cos(nav_QZSS_E0)),(cos(nav_QZSS_E0)-nav_QZSS_e)/(1-nav_QZSS_e*cos(nav_QZSS_E0)));
nav_BDS_trueanomaly0= atan2((sqrt(1-nav_BDS_e^2)*sin(nav_BDS_E0))/(1-nav_BDS_e*cos(nav_BDS_E0)),(cos(nav_BDS_E0)-nav_BDS_e)/(1-nav_BDS_e*cos(nav_BDS_E0)));


%% In Perifocal frame at t

% mean motion
nav_GPS_n = sqrt(mu/nav_GPS_a^3);
nav_QZSS_n = sqrt(mu/nav_QZSS_a^3);
nav_BDS_n = sqrt(mu/nav_BDS_a^3);

% 시간 분 단위로 분할
nav_GPS_time=datetime(nav_GPS_toc)+minutes(1:1440);
nav_QZSS_time=datetime(nav_QZSS_toc)+minutes(1:1440);
nav_BDS_time=datetime(nav_BDS_toc)+minutes(1:1440);

% Get M

for i=1:1440
    nav_GPS_M(i)=nav_GPS_n*60*i+nav_GPS_M0;
    nav_QZSS_M(i)=nav_QZSS_n*60*i+nav_QZSS_M0;
    nav_BDS_M(i)=nav_BDS_n*60*i+nav_BDS_M0;
    
    nav_GPS_M(i)=rem(nav_GPS_M(i),2*pi);
    nav_QZSS_M(i)=rem(nav_QZSS_M(i),2*pi);
    nav_BDS_M(i)=rem(nav_BDS_M(i),2*pi);
end

% Get E from M
for i2=1:1440
    nav_GPS_E(i2)= kepler_eq(nav_GPS_e,nav_GPS_M(i2));
    nav_QZSS_E(i2)= kepler_eq(nav_QZSS_e,nav_QZSS_M(i2));
    nav_BDS_E(i2)= kepler_eq(nav_BDS_e,nav_BDS_M(i2));
end

% Get True anomaly from E
for i3=1:1440
    nav_GPS_trueanomaly(i3)= atan2((sqrt(1-nav_GPS_e^2)*sin(nav_GPS_E(i3)))/(1-nav_GPS_e*cos(nav_GPS_E(i3))),(cos(nav_GPS_E(i3))-nav_GPS_e)/(1-nav_GPS_e*cos(nav_GPS_E(i3))));
    nav_QZSS_trueanomaly(i3)= atan2((sqrt(1-nav_QZSS_e^2)*sin(nav_QZSS_E(i3)))/(1-nav_QZSS_e*cos(nav_QZSS_E(i3))),(cos(nav_QZSS_E(i3))-nav_QZSS_e)/(1-nav_QZSS_e*cos(nav_QZSS_E(i3))));
    nav_BDS_trueanomaly(i3)= atan2((sqrt(1-nav_BDS_e^2)*sin(nav_BDS_E(i3)))/(1-nav_BDS_e*cos(nav_BDS_E(i3))),(cos(nav_BDS_E(i3))-nav_BDS_e)/(1-nav_BDS_e*cos(nav_BDS_E(i3))));
end

% Perifocal frame
for i4=1:1440
    P=nav_GPS_a*(1-nav_GPS_e^2);
    r_scalar=P/(1+nav_GPS_e*cos(nav_GPS_trueanomaly(i4)));
    nav_GPS_PQW(1,i4)=r_scalar*cos(nav_GPS_trueanomaly(i4));
    nav_GPS_PQW(2,i4)=r_scalar*sin(nav_GPS_trueanomaly(i4));
    nav_GPS_PQW(3,i4)=0;

    P=nav_QZSS_a*(1-nav_QZSS_e^2);
    r_scalar=P/(1+nav_QZSS_e*cos(nav_QZSS_trueanomaly(i4)));
    nav_QZSS_PQW(1,i4)=r_scalar*cos(nav_QZSS_trueanomaly(i4));
    nav_QZSS_PQW(2,i4)=r_scalar*sin(nav_QZSS_trueanomaly(i4));
    nav_QZSS_PQW(3,i4)=0;

    P=nav_BDS_a*(1-nav_BDS_e^2);
    r_scalar=P/(1+nav_BDS_e*cos(nav_BDS_trueanomaly(i4)));
    nav_BDS_PQW(1,i4)=r_scalar*cos(nav_BDS_trueanomaly(i4));
    nav_BDS_PQW(2,i4)=r_scalar*sin(nav_BDS_trueanomaly(i4));
    nav_BDS_PQW(3,i4)=0;
end

%% Perifocal to ECI
for i5=1:1440
    nav_GPS_ECI(:,i5)= PQW2ECI(nav_GPS_omega, nav_GPS_i, nav_GPS_OMEGA)*nav_GPS_PQW(:,i5);
    nav_QZSS_ECI(:,i5)= PQW2ECI(nav_QZSS_omega, nav_QZSS_i, nav_QZSS_OMEGA)*nav_QZSS_PQW(:,i5);
    nav_BDS_ECI(:,i5)= PQW2ECI(nav_BDS_omega, nav_BDS_i, nav_BDS_OMEGA)*nav_BDS_PQW(:,i5);
end

%% ECI to ECEF
for i6=1:1440
    nav_GPS_ECEF(:,i6)= ECI2ECEF_DCM(nav_GPS_time(i6))*nav_GPS_ECI(:,i6);
    nav_QZSS_ECEF(:,i6)= ECI2ECEF_DCM(nav_QZSS_time(i6))*nav_QZSS_ECI(:,i6);
    nav_BDS_ECEF(:,i6)= ECI2ECEF_DCM(nav_BDS_time(i6))*nav_BDS_ECI(:,i6);
end

%% ECEF to GEODETIC for Ground Track

wgs84 = wgs84Ellipsoid('kilometer');
for i7=1:1440
    [nav_GPS_lat(i7),nav_GPS_lon(i7),nav_GPS_h(i7)]=ecef2geodetic(wgs84,nav_GPS_ECEF(1,i7),nav_GPS_ECEF(2,i7),nav_GPS_ECEF(3,i7));
    [nav_QZSS_lat(i7),nav_QZSS_lon(i7),nav_QZSS_h(i7)]=ecef2geodetic(wgs84,nav_QZSS_ECEF(1,i7),nav_QZSS_ECEF(2,i7),nav_QZSS_ECEF(3,i7));
    [nav_BDS_lat(i7),nav_BDS_lon(i7),nav_BDS_h(i7)]=ecef2geodetic(wgs84,nav_BDS_ECEF(1,i7),nav_BDS_ECEF(2,i7),nav_BDS_ECEF(3,i7));
end

%% ECEF to ENU

for i8=1:1440
    [nav_GPS_E(i8),nav_GPS_N(i8),nav_GPS_U(i8)]=ecef2enu(nav_GPS_ECEF(1,i8),nav_GPS_ECEF(2,i8),nav_GPS_ECEF(3,i8),37,128,0,wgs84);
    [nav_QZSS_E(i8),nav_QZSS_N(i8),nav_QZSS_U(i8)]=ecef2enu(nav_QZSS_ECEF(1,i8),nav_QZSS_ECEF(2,i8),nav_QZSS_ECEF(3,i8),37,128,0,wgs84);
    [nav_BDS_E(i8),nav_BDS_N(i8),nav_BDS_U(i8)]=ecef2enu(nav_BDS_ECEF(1,i8),nav_BDS_ECEF(2,i8),nav_BDS_ECEF(3,i8),37,128,0,wgs84);    
    
    nav_GPS_ENU(:,i8)=[nav_GPS_E(i8),nav_GPS_N(i8),nav_GPS_U(i8)];
    nav_QZSS_ENU(:,i8)=[nav_QZSS_E(i8),nav_QZSS_N(i8),nav_QZSS_U(i8)];
    nav_BDS_ENU(:,i8)=[nav_BDS_E(i8),nav_BDS_N(i8),nav_BDS_U(i8)];
end

%% ENU to azimuth & elevation for SKY PLOT

nav_GPS_az=azimuth(nav_GPS_ENU);
nav_GPS_el=elevation(nav_GPS_ENU,10);
nav_QZSS_az=azimuth(nav_QZSS_ENU);
nav_QZSS_el=elevation(nav_QZSS_ENU,10);
nav_BDS_az=azimuth(nav_BDS_ENU);
nav_BDS_el=elevation(nav_BDS_ENU,10);

%% plotting
skyplot(nav_GPS_az,nav_GPS_el);
title('GPS')
figure
skyplot(nav_QZSS_az,nav_QZSS_el);
title('QZSS')
figure
skyplot(nav_BDS_az,nav_BDS_el);
title('BDS')
figure
geoplot(nav_GPS_lat,nav_GPS_lon,'b.');
title('GPS')
figure
geoplot(nav_QZSS_lat,nav_QZSS_lon,'b.');
title('QZSS')
figure
geoplot(nav_BDS_lat,nav_BDS_lon,'b.');
title('BDS')
